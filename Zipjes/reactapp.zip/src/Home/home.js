function Home(){
    return(
        <h1>Welkom op deze website!</h1>
    );
}

export default Home;